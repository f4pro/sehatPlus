package com.faizil.sehatplus

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.faizil.sehatplus.auth.LoginActivity
import com.faizil.sehatplus.databinding.ActivityHomeBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class home : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private lateinit var firebaseAuth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        checkUser()

        binding.LogoutBtn.setOnClickListener {
            firebaseAuth.signOut()
            checkUser()
        }
    }


    private fun checkUser() {
        val fireUser = firebaseAuth.currentUser
        if (fireUser != null) {
            val email = fireUser.email
            //val uName = fireUser.displayName.toString()

            binding.emailNow.text = email
        }  else {
            Toast.makeText(this, "Goodbye!", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

    }
}