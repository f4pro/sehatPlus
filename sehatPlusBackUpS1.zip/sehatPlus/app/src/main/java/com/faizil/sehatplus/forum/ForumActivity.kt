package com.faizil.sehatplus.forum

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.faizil.sehatplus.databinding.ActivityForumBinding
import kotlinx.android.synthetic.main.activity_forum.*

class ForumActivity : AppCompatActivity() {
    private lateinit var binding: ActivityForumBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForumBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.titleActTv.text = "Forum"

        binding.backBtn.setOnClickListener {
            onBackPressed()
            finish()
        }

        val forumBottomSheet = ForumBottomSheet()

        addForumBtn.setOnClickListener {
            forumBottomSheet.show(supportFragmentManager, "fragmentDialog")
        }
    }
}