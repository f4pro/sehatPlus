package com.faizil.sehatplus.doctor

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.faizil.sehatplus.databinding.ActivityDoctorBinding

class DoctorActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDoctorBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDoctorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.titleActTv.text = "Doctor"

        binding.backBtn.setOnClickListener {
            onBackPressed()
            finish()
        }
    }
}